package test2;

public class Construct {
    public Construct(int i) {}
    public Construct() {}
    static int i = 3;
}
