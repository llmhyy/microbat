package test2;

public class SetExceptions {
    public void f() throws Exception {
        throw new Exception();
    }
}
