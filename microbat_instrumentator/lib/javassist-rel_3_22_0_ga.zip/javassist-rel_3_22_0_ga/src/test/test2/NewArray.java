package test2;

public class NewArray {
    public int run() {
        return foo(1);
    }

    public int foo(int i) {
        String[] s1 = new String[3];
        String[][] s2 = new String[4][];
        String[][] s3 = new String[5][6];
        int[] i1 = new int[7];
        int[][] i2 = new int[8][];
        int[][] i3 = new int[9][10];
        int[][][] i4 = new int[11][12][];
        return i;
    }
}
