package test3;

public class InnerClass {
    int y;
    public static class Inner { int x; }
    public class Inner2 { int x; }
}
