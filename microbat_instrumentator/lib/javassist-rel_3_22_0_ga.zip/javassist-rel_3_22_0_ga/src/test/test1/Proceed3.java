package test1;

public class Proceed3 {
    public int p(int i) { return i; }

    public int k1() {
	return p(3);
    }
}
